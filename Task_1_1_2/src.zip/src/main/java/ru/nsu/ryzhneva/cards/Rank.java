package ru.nsu.ryzhneva.cards;

/**
 * Перечисление возможных достоинств карт.
 */
public enum Rank {
    Ace, Two, Three, Four, Five, Six, Seven,
    Eight, Nine, Ten, Jack, Queen, King
}
