package ru.nsu.ryzhneva.cards;

/**
 * Перечисление возможных мастей карт.
 */
public enum Suit {
    Spades, Hearts, Diamonds, Clubs
}

